按照下面步骤在本目录/codes下操作
mkdir build
cd build
cmake ..
make
make runAssignment
make doc #此步依赖于前一步#

之后，在/codes/doc中阅读design.pdf和report.pdf即可
清理方式为 make cleanDoc。

附：
Tree View of Codes
codes
├── bin
│   ├── main
│   │   └── PROJECT3_ASSIGNMENT
│   └── test
│       ├── TEST_CARDINAL_CMAKE
│       └── TEST_SPLINE_CMAKE
├── build
│   ├──(...)
│
├── CMakeLists.txt
├── doc
│   ├── CMakeLists.txt
│   └── doc.tex
├── include
│   ├── CardinalBspline.H
│   ├── Config.H
│   ├── InterpConditions.H
│   ├── NewtonInterp_Portable.H
│   ├── Polynomial.H
│   ├── Spline.H
│   ├── TriangleTable.H
│   └── Vec.h
├── main
│   ├── Assignment.cpp
│   ├── CMakeLists.txt
│   └── SnippetsForAssignment.cpp
├── output
│   ├──(...)
│
└── readme.md
    
$\textbf{bin}$ stores compiled files;\\
$\textbf{doc}$ stores design and report documents;\\
$\textbf{include}$ stores sources files that support spline implementation;\\
$\textbf{main}$ stores files concerning the assignments;\\
$\textbf{output}$ stores all results such as $\textbf{*.m}$ and $\textbf{*.png}$.

